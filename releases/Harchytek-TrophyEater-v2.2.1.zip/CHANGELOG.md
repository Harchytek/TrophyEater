## v2.2.1
* Added a new `General` configuration category to organize plugin-level settings.
* Added a Shortcut Toggle for trophy consumption (requested by cscampbell93).
* Set `End` as the default toggle key.

## v2.1.1
* Fixed an issue with using boss trophies or summoning items to spawn bosses.

## v2.0.1
* Updated for Valheim 1.0 Deep North.
* Changes the way trophies are consumed to avoid interference with other mods.

*The Deep North trophies will be added later.*

## v1.0.1
* Updated to support the latest website layout and display changes.

## v1.0.0
* Initial release